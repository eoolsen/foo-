﻿using Danske.Bank.DAL.Interfaces;
using Danske.Bank.Model;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/// <summary>
/// Author: Ankit Tayal
/// Detail: This class gives all implementation related to company and owner.
/// Creation Date : 13-12-2020
/// </summary>
namespace Danske.Bank.DAL
{
    public class CompanyRepository : ICompanyRepository
    {
        private readonly CompanyDatabaseContext _databaseContext;
        private readonly IServiceScope _scope;

        public CompanyRepository(IServiceProvider services)
        {
            _scope = services.CreateScope();

            _databaseContext = _scope.ServiceProvider.GetRequiredService<CompanyDatabaseContext>();
        }

        public List<CompanyModel> GetCompanies()
        {
            var result = _databaseContext.Company.ToList();

            return result;
        }

        public async Task<bool> CreateCompany(CompanyModel companyInfo)
        {
            var success = false;

            _databaseContext.Company.Add(companyInfo);

            var numberOfItemsCreated = await _databaseContext.SaveChangesAsync();

            if (numberOfItemsCreated > 0)
                success = true;

            return success;
        }

        public CompanyModel GetCompanyById(int id)
        {
            var result = _databaseContext.Company.Where(x=>x.CompanyId == id).FirstOrDefault();

            return result;
        }

        public async Task<bool> UpdateCompany(CompanyModel companyInfo)
        {
            var success = false;

            var existingCompany = GetCompanyById(companyInfo.CompanyId);

            if (existingCompany != null)
            {
                existingCompany.CompanyName = companyInfo.CompanyName;
                existingCompany.Country = companyInfo.Country;
                existingCompany.PhoneNo = companyInfo.PhoneNo;

                _databaseContext.Company.Attach(existingCompany);

                var numberOfItemsUpdated = await _databaseContext.SaveChangesAsync();

                if (numberOfItemsUpdated == 1)
                    success = true;
            }

            return success;
        }

        public async Task<bool> AddOwnerToCompany(CompanyModel companyInfo)
        {
            var success = false;

            var existingCompany = GetCompanyById(companyInfo.CompanyId);

            if (existingCompany != null)
            {
                foreach (var com in companyInfo.OwnerList)
                {
                    existingCompany.OwnerList.Add(new OwnerModel { Name = com.Name, SSN = com.SSN });
                }

                _databaseContext.Company.Attach(existingCompany);

                var numberOfItemsUpdated = await _databaseContext.SaveChangesAsync();

                if (numberOfItemsUpdated == 1)
                    success = true;
            }

            return success;
        }

        public List<int> GetAllSSN()
        {
            var results = _databaseContext.Owner.Select(x=>x.SSN).ToList();

            return results;
        }
    }
}
