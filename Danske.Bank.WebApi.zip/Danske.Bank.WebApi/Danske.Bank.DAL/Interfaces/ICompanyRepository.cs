﻿using Danske.Bank.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Danske.Bank.DAL.Interfaces
{
    public interface ICompanyRepository
    {
        Task<bool> CreateCompany(CompanyModel companyInfo);
        List<CompanyModel> GetCompanies();
        CompanyModel GetCompanyById(int id);
        Task<bool> UpdateCompany(CompanyModel companyInfo);
        Task<bool> AddOwnerToCompany(CompanyModel companyInfo);
        List<int> GetAllSSN();
    }
}
