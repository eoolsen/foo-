﻿
using Danske.Bank.Model;
using Microsoft.EntityFrameworkCore;


namespace Danske.Bank.DAL
{
    public class CompanyDatabaseContext : DbContext
    {
        public CompanyDatabaseContext(DbContextOptions<CompanyDatabaseContext> options)
           : base(options)
        {
        }

        public DbSet<CompanyModel> Company { get; set; }

        public DbSet<OwnerModel> Owner { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CompanyModel>().HasKey(x => x.CompanyId);
            modelBuilder.Entity<OwnerModel>().HasKey(x => x.OwnerId);
        }
    }
}
