﻿using Danske.Bank.DAL.Interfaces;
using Danske.Bank.Model;
using Danske.Bank.Service.Interfaces;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Danske.Bank.Service
{
    public class CompanyService : ICompanyService
    {
        private readonly ICompanyRepository _repository;

        public CompanyService(ICompanyRepository repository)
        {
            _repository = repository;
        }

        public async Task<CompanyModel> CreateCompany(CompanyModel companyInfo)
        {
            var success = await _repository.CreateCompany(companyInfo);

            if (success)
                return companyInfo;
            else
                return null;            
        }

        public List<CompanyModel> GetCompanies()
        {
            List<CompanyModel> lstCompanies = new List<CompanyModel>();
            lstCompanies = _repository.GetCompanies();

            return lstCompanies;
        }

        public CompanyModel GetCompanyById(int id)
        {
            CompanyModel company = new CompanyModel();
            company = _repository.GetCompanyById(id);

            return company;
        }

        public async Task<CompanyModel> UpdateCompany(CompanyModel companyInfo)
        {
            var success = await _repository.UpdateCompany(companyInfo);

            if (success)
                return companyInfo;
            else
                return null;
        }

        public async Task<CompanyModel> AddOwnerToCompany(CompanyModel companyInfo)
        {
            var success = await _repository.AddOwnerToCompany(companyInfo);

            if (success)
                return companyInfo;
            else
                return null;
        }

        public string GetSSNStatus(int ssn)
        {
            List<int> lstSSN = _repository.GetAllSSN();

            bool isTrue = lstSSN.Contains(ssn);

            string status;
            if (isTrue)
                status = "Valid";
            else
                status = "Invalid";

            return status;
        }

        public List<int> GetSSN()
        {
            var result = _repository.GetAllSSN();

            return result;
        }
    }

}
