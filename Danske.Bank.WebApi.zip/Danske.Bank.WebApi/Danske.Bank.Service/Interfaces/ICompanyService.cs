﻿using Danske.Bank.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Danske.Bank.Service.Interfaces
{
    public interface ICompanyService
    {
        Task<CompanyModel> CreateCompany(CompanyModel companyInfo);
        List<CompanyModel> GetCompanies();
        CompanyModel GetCompanyById(int id);
        Task<CompanyModel> UpdateCompany(CompanyModel companyInfo);
        Task<CompanyModel> AddOwnerToCompany(CompanyModel companyInfo);
        string GetSSNStatus(int ssn);
        List<int> GetSSN();
    }
}
