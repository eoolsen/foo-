﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

namespace Danske.Bank.WebApi.Controllers
{
    public class AbstractController : Controller
    {
        public JsonResult HandleException(Exception ex, ILogger logger, string customMessage)
        {
            Response.StatusCode = Response.StatusCode != 400 ? 500 : 400;

            if (Response.StatusCode == 400)
            {
                customMessage = ex.Message;
            }
            logger.LogError(ex, ex.StackTrace, ex.InnerException, customMessage);

            return Json(new
            {
                status = Response.StatusCode,
                error = string.IsNullOrWhiteSpace(customMessage) ? "Exception while processing the request" : customMessage
            });
        }
    }
}
