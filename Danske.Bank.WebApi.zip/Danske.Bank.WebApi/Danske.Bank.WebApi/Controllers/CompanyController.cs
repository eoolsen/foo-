﻿using Danske.Bank.Model;
using Danske.Bank.Service.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

/// <summary>
/// Author: Ankit Tayal
/// Detail: This controller holds all APIs related to company and owner.
/// Creation Date : 13-12-2020
/// </summary>

namespace Danske.Bank.WebApi.Controllers
{
    [Route("api/[controller]")]
    public class CompanyController : AbstractController
    {
        private readonly ICompanyService _companyService;
        private readonly ILogger<CompanyController> _logger;
        public CompanyController(ICompanyService companyService, ILogger<CompanyController> logger)
        {
            _companyService = companyService;
            _logger = logger;
        }

        /// <summary>
        /// This API will create a company based on model provided.
        /// </summary>
        /// <param name="companyInfo"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateCompany")]
        public async Task<IActionResult> CreateCompany([FromBody] CompanyModel companyInfo)
        {
            try
            {
                var result = await _companyService.CreateCompany(companyInfo);

                return CreatedAtAction(
                        nameof(GetCompanies),
                        new { id = result.CompanyId }, result);
            }
            catch (Exception ex)
            {
                return HandleException(ex, _logger, "CreateCompany");
            }
        }


        /// <summary>
        /// This API will list all the companies.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetCompanies")]       
        public IActionResult GetCompanies()
        {
            try
            {
                var result = _companyService.GetCompanies();

                return Ok(result);
            }
            catch (Exception ex)
            {
                return HandleException(ex, _logger, "GetCompanies");
            }
        }


        /// <summary>
        /// This API will give the details about a company based on CompanyId.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetCompanyById")]
        public IActionResult GetCompanyById(int id)
        {
            try
            {
                var result = _companyService.GetCompanyById(id);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return HandleException(ex, _logger, "GetCompanyById");
            }
        }


        /// <summary>
        /// This API will give the update the details of a company i.e. Phone No, Country, Name etc.
        /// </summary>
        /// <param name="companyInfo"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateCompany")]
        public async Task<IActionResult> UpdateCompany([FromBody] CompanyModel companyInfo)
        {
            try
            {
                var result = await _companyService.UpdateCompany(companyInfo);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return HandleException(ex, _logger, "UpdateCompany");
            }
            
        }


        /// <summary>
        /// This API will add the onwer(s) to the existing company.
        /// </summary>
        /// <param name="companyInfo"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddOwnerToCompany")]
        public async Task<IActionResult> AddOwnerToCompany([FromBody]CompanyModel companyInfo)
        {
            try
            {
                var result = await _companyService.AddOwnerToCompany(companyInfo);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return HandleException(ex, _logger, "AddOwnerToCompany");
            }
            
        }


        /// <summary>
        /// This API will give the status for a given SSN. This will return Valid or Invalid.
        /// </summary>
        /// <param name="ssn"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetSSNStatus")]
        public IActionResult GetSSNStatus(int ssn)
        {
            try
            {
                var result = _companyService.GetSSNStatus(ssn);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return HandleException(ex, _logger, "GetSSNStatus");
            }
            
        }


        /// <summary>
        /// This API will return the list of available SSN based on the Rold. Assumed Role will be passed in
        /// the form of IsAdmin true or false.
        /// </summary>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetSSN")]
        public IActionResult GetSSN(bool isAdmin)
        {
            try
            {
                if (isAdmin)
                {
                    var result = _companyService.GetSSN();
                    return Ok(result);
                }
                else
                    return Ok("No Access to SSN");
            }
            catch (Exception ex)
            {
                return HandleException(ex, _logger, "GetSSN");
            }
            
        }
    }
}
